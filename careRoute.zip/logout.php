<?php
include('includes/cleanCookies.php');
// setcookie("logged_in", "");
// setcookie("username", "");
// setcookie("session", "");
// setcookie("login_time", "");
print '<script language="JavaScript">window.location="login.php";</script>';
exit;
